#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>
#include <RTClib.h>
#include <SPI.h>
#include <SD.h>

#include <cmath>
#include <cstring>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <freertos/semphr.h>

// ============================================================
// Smart Environment Monitoring System
// ESP32 DevKit V1 + FreeRTOS + Arduino Framework
// ============================================================

namespace config {

// Display configuration.
constexpr uint8_t SCREEN_WIDTH = 128;
constexpr uint8_t SCREEN_HEIGHT = 64;
constexpr uint8_t OLED_ADDRESS = 0x3C;

// I2C shared bus.
constexpr uint8_t I2C_SDA_PIN = 21;
constexpr uint8_t I2C_SCL_PIN = 22;

// Sensor and actuator pins.
constexpr uint8_t DHT_PIN = 4;
constexpr uint8_t POT_PIN = 35;
constexpr uint8_t HC_SR04_TRIG_PIN = 18;
constexpr uint8_t HC_SR04_ECHO_PIN = 19;
constexpr uint8_t LED_INDICATOR_PIN = 2;
constexpr uint8_t BUTTON_PIN = 23;
constexpr uint8_t DAC_OUTPUT_PIN = 25;

// SPI SD Card pins (HSPI, separated from sensor pins).
constexpr uint8_t SD_SCK_PIN = 14;
constexpr uint8_t SD_MISO_PIN = 27;
constexpr uint8_t SD_MOSI_PIN = 26;
constexpr uint8_t SD_CS_PIN = 5;

// Sensor type.
constexpr uint8_t DHT_TYPE = DHT22;

// Task timing.
constexpr TickType_t DHT_PERIOD = pdMS_TO_TICKS(2000);
constexpr TickType_t RTC_PERIOD = pdMS_TO_TICKS(1000);
constexpr TickType_t ADC_PERIOD = pdMS_TO_TICKS(200);
constexpr TickType_t ULTRASONIC_PERIOD = pdMS_TO_TICKS(300);
constexpr TickType_t OLED_PERIOD = pdMS_TO_TICKS(150);
constexpr TickType_t LED_PERIOD = pdMS_TO_TICKS(100);
constexpr TickType_t SD_LOG_PERIOD = pdMS_TO_TICKS(5000);
constexpr TickType_t BUTTON_DEBOUNCE_PERIOD = pdMS_TO_TICKS(200);

// Object detection threshold.
constexpr float PROXIMITY_THRESHOLD_CM = 20.0f;

// FreeRTOS stack sizes.
constexpr uint32_t STACK_DHT = 4096;
constexpr uint32_t STACK_RTC = 4096;
constexpr uint32_t STACK_ADC = 3072;
constexpr uint32_t STACK_ULTRASONIC = 3072;
constexpr uint32_t STACK_OLED = 6144;
constexpr uint32_t STACK_LED = 2048;
constexpr uint32_t STACK_SD = 4096;
constexpr uint32_t STACK_BUTTON = 2048;

// Page count for OLED multi-page interface.
constexpr uint8_t OLED_PAGE_COUNT = 4;

}  // namespace config

struct SensorData {
	float dhtTemperatureC;
	float dhtHumidity;
	float rtcTemperatureC;
	float distanceCm;
	float adcVoltage;
	uint16_t adcRaw;
	uint8_t dacValue;
	bool dhtValid;
	bool rtcValid;
	bool ultrasonicValid;
	bool proximityAlert;
	bool ledOutputState;
	bool sdCardReady;
	char timeText[16];
	char dateText[16];
};

// Shared peripherals.
Adafruit_SSD1306 display(config::SCREEN_WIDTH, config::SCREEN_HEIGHT, &Wire, -1);
DHT dht(config::DHT_PIN, config::DHT_TYPE);
RTC_DS3231 rtc;
SPIClass sdSpi(HSPI);

// FreeRTOS primitives.
QueueHandle_t sensorQueue = nullptr;
SemaphoreHandle_t dataMutex = nullptr;
SemaphoreHandle_t i2cMutex = nullptr;
SemaphoreHandle_t buttonSemaphore = nullptr;
SemaphoreHandle_t sdMutex = nullptr;

// Runtime flags.
volatile uint8_t currentPage = 0;
bool displayReady = false;
bool rtcReady = false;
bool sdReady = false;

// Shared sensor snapshot.
SensorData sharedData;

// Task handles are kept for clarity and future maintenance.
TaskHandle_t taskDHTHandle = nullptr;
TaskHandle_t taskRTCHandle = nullptr;
TaskHandle_t taskADCHandle = nullptr;
TaskHandle_t taskUltrasonicHandle = nullptr;
TaskHandle_t taskOLEDHandle = nullptr;
TaskHandle_t taskLEDHandle = nullptr;
TaskHandle_t taskSDHandle = nullptr;
TaskHandle_t taskButtonHandle = nullptr;

// ============================================================
// Helper functions
// ============================================================

static void copySharedDataToQueue();

static void initSharedData() {
	memset(&sharedData, 0, sizeof(sharedData));
	sharedData.dhtTemperatureC = NAN;
	sharedData.dhtHumidity = NAN;
	sharedData.rtcTemperatureC = NAN;
	sharedData.distanceCm = NAN;
	sharedData.adcVoltage = NAN;
	sharedData.adcRaw = 0;
	sharedData.dacValue = 0;
	sharedData.dhtValid = false;
	sharedData.rtcValid = false;
	sharedData.ultrasonicValid = false;
	sharedData.proximityAlert = false;
	sharedData.ledOutputState = false;
	sharedData.sdCardReady = false;
	snprintf(sharedData.timeText, sizeof(sharedData.timeText), "--:--:--");
	snprintf(sharedData.dateText, sizeof(sharedData.dateText), "--/--/----");
}

static bool initSDCard() {
	if (sdMutex == nullptr) {
		return false;
	}

	bool initOk = false;
	if (xSemaphoreTake(sdMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
		sdSpi.begin(config::SD_SCK_PIN, config::SD_MISO_PIN, config::SD_MOSI_PIN, config::SD_CS_PIN);
		initOk = SD.begin(config::SD_CS_PIN, sdSpi);
		if (initOk && !SD.exists("/sensor_log.csv")) {
			File file = SD.open("/sensor_log.csv", FILE_WRITE);
			if (file) {
				file.println("millis,time,date,dht_temp_c,dht_humidity,rct_temp_c,adc_raw,adc_v,dac,dist_cm,led");
				file.close();
			}
		}
		xSemaphoreGive(sdMutex);
	}

	if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
		sharedData.sdCardReady = initOk;
		xSemaphoreGive(dataMutex);
		copySharedDataToQueue();
	}

	return initOk;
}

static bool appendSensorLogToSD(const SensorData &data) {
	if (!sdReady || sdMutex == nullptr) {
		return false;
	}

	bool success = false;
	if (xSemaphoreTake(sdMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
		File file = SD.open("/sensor_log.csv", FILE_APPEND);
		if (file) {
			const float dhtTemp = data.dhtValid ? data.dhtTemperatureC : -999.0f;
			const float dhtHum = data.dhtValid ? data.dhtHumidity : -1.0f;
			const float rtcTemp = data.rtcValid ? data.rtcTemperatureC : -999.0f;
			const float dist = data.ultrasonicValid ? data.distanceCm : -1.0f;
			file.printf(
				"%lu,%s,%s,%.2f,%.2f,%.2f,%u,%.3f,%u,%.2f,%u\n",
				static_cast<unsigned long>(millis()),
				data.timeText,
				data.dateText,
				dhtTemp,
				dhtHum,
				rtcTemp,
				static_cast<unsigned int>(data.adcRaw),
				data.adcVoltage,
				static_cast<unsigned int>(data.dacValue),
				dist,
				data.ledOutputState ? 1U : 0U);
			file.close();
			success = true;
		}
		xSemaphoreGive(sdMutex);
	}

	return success;
}

static void copySharedDataToQueue() {
	if (sensorQueue == nullptr || dataMutex == nullptr) {
		return;
	}

	SensorData snapshot;
	if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
		snapshot = sharedData;
		xSemaphoreGive(dataMutex);
		xQueueOverwrite(sensorQueue, &snapshot);
	}
}

static void setInvalidRtcText(SensorData &data) {
	data.rtcValid = false;
	snprintf(data.timeText, sizeof(data.timeText), "--:--:--");
	snprintf(data.dateText, sizeof(data.dateText), "--/--/----");
}

static void updateRtcText(SensorData &data, const DateTime &now) {
	data.rtcValid = true;
	snprintf(data.timeText, sizeof(data.timeText), "%02d:%02d:%02d", now.hour(), now.minute(), now.second());
	snprintf(data.dateText, sizeof(data.dateText), "%02d/%02d/%04d", now.day(), now.month(), now.year());
}

static float readUltrasonicDistanceCm() {
	digitalWrite(config::HC_SR04_TRIG_PIN, LOW);
	delayMicroseconds(2);
	digitalWrite(config::HC_SR04_TRIG_PIN, HIGH);
	delayMicroseconds(10);
	digitalWrite(config::HC_SR04_TRIG_PIN, LOW);

	const unsigned long duration = pulseIn(config::HC_SR04_ECHO_PIN, HIGH, 30000UL);
	if (duration == 0) {
		return NAN;
	}

	return static_cast<float>(duration) / 58.0f;
}

static const char *ledModeText(const SensorData &data) {
	if (data.proximityAlert) {
		return "ALERT";
	}

	return data.ledOutputState ? "BLINK ON" : "BLINK OFF";
}

static void drawPageFooter(Adafruit_SSD1306 &oled, const SensorData &data, const char *pageLabel, const char *pageName) {
	oled.setCursor(0, 0);
	oled.println(F("SMART ENV MONITOR"));
	oled.println(pageLabel);
	oled.println(pageName);

	char line[32];
	snprintf(line, sizeof(line), "LED  : %s", data.ledOutputState ? "ON" : "OFF");
	oled.println(line);
	snprintf(line, sizeof(line), "Mode : %s", ledModeText(data));
	oled.println(line);
}

static void renderPageDHT(Adafruit_SSD1306 &oled, const SensorData &data) {
	char line[32];

	oled.setTextSize(1);
	oled.setTextColor(SSD1306_WHITE);
	drawPageFooter(oled, data, "Page 1/4", "DHT22 MONITOR");
	oled.println();

	if (data.dhtValid) {
		snprintf(line, sizeof(line), "Temp : %0.1f C", data.dhtTemperatureC);
	} else {
		snprintf(line, sizeof(line), "Temp : sensor error");
	}
	oled.println(line);

	if (data.dhtValid) {
		snprintf(line, sizeof(line), "Hum  : %0.1f %%", data.dhtHumidity);
	} else {
		snprintf(line, sizeof(line), "Hum  : sensor error");
	}
	oled.println(line);

	if (data.dhtValid) {
		snprintf(line, sizeof(line), "Heat : %0.1f C", data.dhtTemperatureC);
	} else {
		snprintf(line, sizeof(line), "Heat : --.- C");
	}
	oled.println(line);
}

static void renderPageRTC(Adafruit_SSD1306 &oled, const SensorData &data) {
	char line[32];

	oled.setTextSize(1);
	oled.setTextColor(SSD1306_WHITE);
	oled.setCursor(0, 0);
	oled.println(F("RTC DS3231"));
	oled.println(F("Page 2/4"));

	if (data.rtcValid) {
		snprintf(line, sizeof(line), "Time: %s", data.timeText);
	} else {
		snprintf(line, sizeof(line), "Time: --:--:--");
	}
	oled.println(line);

	if (data.rtcValid) {
		snprintf(line, sizeof(line), "Date: %s", data.dateText);
	} else {
		snprintf(line, sizeof(line), "Date: --/--/----");
	}
	oled.println(line);

	if (data.rtcValid) {
		snprintf(line, sizeof(line), "Temp: %0.1f C", data.rtcTemperatureC);
	} else {
		snprintf(line, sizeof(line), "Temp: error");
	}
	oled.println(line);

	snprintf(line, sizeof(line), "Status: %s", data.rtcValid ? "OK" : "NO RTC");
	oled.println(line);
}

static void renderPagePotentiometer(Adafruit_SSD1306 &oled, const SensorData &data) {
	char line[32];

	oled.setTextSize(1);
	oled.setTextColor(SSD1306_WHITE);
	oled.setCursor(0, 0);
	oled.println(F("POTENSIOMETER + DAC"));
	oled.println(F("Page 3/4"));

	oled.setCursor(0, 18);
	snprintf(line, sizeof(line), "ADC Raw : %u", data.adcRaw);
	oled.println(line);

	oled.setCursor(0, 28);
	if (isnan(data.adcVoltage)) {
		snprintf(line, sizeof(line), "ADC V   : --.- V");
	} else {
		snprintf(line, sizeof(line), "ADC V   : %0.2f V", data.adcVoltage);
	}
	oled.println(line);

	oled.setCursor(0, 38);
	snprintf(line, sizeof(line), "DAC OUT : %u / 255", data.dacValue);
	oled.println(line);

	const int barWidth = map(data.dacValue, 0, 255, 0, 120);
	oled.setCursor(0, 48);
	snprintf(line, sizeof(line), "LED ADC: %s", data.ledOutputState ? "ON" : "OFF");
	oled.println(line);

	oled.drawRect(0, 56, 128, 8, SSD1306_WHITE);
	oled.fillRect(4, 58, barWidth, 4, SSD1306_WHITE);
}

static void renderPageUltrasonic(Adafruit_SSD1306 &oled, const SensorData &data) {
	char line[32];

	oled.setTextSize(1);
	oled.setTextColor(SSD1306_WHITE);
	drawPageFooter(oled, data, "Page 4/4", "HC-SR04 MONITOR");
	oled.println();

	if (data.ultrasonicValid) {
		snprintf(line, sizeof(line), "Distance: %0.1f cm", data.distanceCm);
	} else {
		snprintf(line, sizeof(line), "Distance: no echo");
	}
	oled.println(line);

	snprintf(line, sizeof(line), "Thresh  : <= %0.1f cm", config::PROXIMITY_THRESHOLD_CM);
	oled.println(line);

	snprintf(line, sizeof(line), "Status  : %s", data.proximityAlert ? "DEKAT" : "AMAN");
	oled.println(line);

	snprintf(line, sizeof(line), "SD Card : %s", data.sdCardReady ? "READY" : "OFF");
	oled.println(line);
}

static void renderOledFrame(const SensorData &data) {
	if (!displayReady) {
		return;
	}

	display.clearDisplay();

	switch (currentPage % config::OLED_PAGE_COUNT) {
		case 0:
			renderPageDHT(display, data);
			break;
		case 1:
			renderPageRTC(display, data);
			break;
		case 2:
			renderPagePotentiometer(display, data);
			break;
		default:
			renderPageUltrasonic(display, data);
			break;
	}

	if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
		display.display();
		xSemaphoreGive(i2cMutex);
	}
}

// ============================================================
// Interrupt service routine
// ============================================================

void IRAM_ATTR buttonISR() {
	if (buttonSemaphore == nullptr) {
		return;
	}

	BaseType_t higherPriorityTaskWoken = pdFALSE;
	xSemaphoreGiveFromISR(buttonSemaphore, &higherPriorityTaskWoken);
	if (higherPriorityTaskWoken == pdTRUE) {
		portYIELD_FROM_ISR();
	}
}

// ============================================================
// FreeRTOS tasks
// ============================================================

void TaskDHT(void *parameter) {
	(void)parameter;

	for (;;) {
		const float temperature = dht.readTemperature();
		const float humidity = dht.readHumidity();

		if (xSemaphoreTake(dataMutex, portMAX_DELAY) == pdTRUE) {
			sharedData.dhtTemperatureC = temperature;
			sharedData.dhtHumidity = humidity;
			sharedData.dhtValid = !isnan(temperature) && !isnan(humidity);
			xSemaphoreGive(dataMutex);
			copySharedDataToQueue();
		}

		vTaskDelay(config::DHT_PERIOD);
	}
}

void TaskRTC(void *parameter) {
	(void)parameter;

	for (;;) {
		if (rtcReady) {
			if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
				const DateTime now = rtc.now();
				const float rtcTemperature = rtc.getTemperature();
				xSemaphoreGive(i2cMutex);

				if (xSemaphoreTake(dataMutex, portMAX_DELAY) == pdTRUE) {
					updateRtcText(sharedData, now);
					sharedData.rtcTemperatureC = rtcTemperature;
					sharedData.rtcValid = !isnan(rtcTemperature);
					xSemaphoreGive(dataMutex);
					copySharedDataToQueue();
				}
			}
		} else {
			if (xSemaphoreTake(dataMutex, portMAX_DELAY) == pdTRUE) {
				setInvalidRtcText(sharedData);
				sharedData.rtcTemperatureC = NAN;
				xSemaphoreGive(dataMutex);
				copySharedDataToQueue();
			}
		}

		vTaskDelay(config::RTC_PERIOD);
	}
}

void TaskADC(void *parameter) {
	(void)parameter;

	for (;;) {
		const uint16_t rawValue = static_cast<uint16_t>(analogRead(config::POT_PIN));
		const uint8_t dacValue = static_cast<uint8_t>(map(rawValue, 0, 4095, 0, 255));
		const float voltage = static_cast<float>(rawValue) * 3.3f / 4095.0f;

		dacWrite(config::DAC_OUTPUT_PIN, dacValue);

		if (xSemaphoreTake(dataMutex, portMAX_DELAY) == pdTRUE) {
			sharedData.adcRaw = rawValue;
			sharedData.dacValue = dacValue;
			sharedData.adcVoltage = voltage;
			xSemaphoreGive(dataMutex);
			copySharedDataToQueue();
		}

		vTaskDelay(config::ADC_PERIOD);
	}
}

void TaskUltrasonic(void *parameter) {
	(void)parameter;

	float filteredDistance = NAN;

	for (;;) {
		const float measuredDistance = readUltrasonicDistanceCm();

		if (!isnan(measuredDistance)) {
			if (isnan(filteredDistance)) {
				filteredDistance = measuredDistance;
			} else {
				filteredDistance = (0.7f * filteredDistance) + (0.3f * measuredDistance);
			}
		}

		if (xSemaphoreTake(dataMutex, portMAX_DELAY) == pdTRUE) {
			sharedData.distanceCm = filteredDistance;
			sharedData.ultrasonicValid = !isnan(filteredDistance);
			sharedData.proximityAlert = sharedData.ultrasonicValid && (filteredDistance <= config::PROXIMITY_THRESHOLD_CM);
			xSemaphoreGive(dataMutex);
			copySharedDataToQueue();
		}

		vTaskDelay(config::ULTRASONIC_PERIOD);
	}
}

void TaskOLED(void *parameter) {
	(void)parameter;

	SensorData frame = {};
	if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
		frame = sharedData;
		xSemaphoreGive(dataMutex);
	}

	for (;;) {
		SensorData incoming = {};
		while (xQueueReceive(sensorQueue, &incoming, 0) == pdTRUE) {
			frame = incoming;
		}

		renderOledFrame(frame);
		vTaskDelay(config::OLED_PERIOD);
	}
}

void TaskLED(void *parameter) {
	(void)parameter;

	for (;;) {
		SensorData localData = {};
		if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
			localData = sharedData;
			xSemaphoreGive(dataMutex);
		}

		const bool ledState = (localData.adcRaw >= (4095 / 2));
		digitalWrite(config::LED_INDICATOR_PIN, ledState ? HIGH : LOW);

		if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
			sharedData.ledOutputState = ledState;
			xSemaphoreGive(dataMutex);
			copySharedDataToQueue();
		}

		vTaskDelay(config::LED_PERIOD);
	}
}

void TaskButton(void *parameter) {
	(void)parameter;

	TickType_t lastHandledTick = 0;

	for (;;) {
		if (xSemaphoreTake(buttonSemaphore, portMAX_DELAY) == pdTRUE) {
			const TickType_t nowTick = xTaskGetTickCount();
			if ((nowTick - lastHandledTick) >= config::BUTTON_DEBOUNCE_PERIOD) {
				lastHandledTick = nowTick;
				vTaskDelay(pdMS_TO_TICKS(40));

				if (digitalRead(config::BUTTON_PIN) == LOW) {
					currentPage = (currentPage + 1) % config::OLED_PAGE_COUNT;
				}
			}

			vTaskDelay(pdMS_TO_TICKS(10));
		}
	}
}

void TaskSDCard(void *parameter) {
	(void)parameter;

	for (;;) {
		if (!sdReady) {
			sdReady = initSDCard();
			if (!sdReady) {
				Serial.println(F("SD init failed, retrying..."));
				vTaskDelay(config::SD_LOG_PERIOD);
				continue;
			}
			Serial.println(F("SD card initialized."));
		}

		SensorData snapshot = {};
		if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
			snapshot = sharedData;
			xSemaphoreGive(dataMutex);
		}

		if (!appendSensorLogToSD(snapshot)) {
			sdReady = false;
			if (xSemaphoreTake(dataMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
				sharedData.sdCardReady = false;
				xSemaphoreGive(dataMutex);
				copySharedDataToQueue();
			}
			Serial.println(F("SD write failed, reinitializing..."));
		}

		vTaskDelay(config::SD_LOG_PERIOD);
	}
}

// ============================================================
// Arduino setup and loop
// ============================================================

void setup() {
	Serial.begin(115200);
	vTaskDelay(pdMS_TO_TICKS(200));

	initSharedData();

	pinMode(config::LED_INDICATOR_PIN, OUTPUT);
	pinMode(config::BUTTON_PIN, INPUT_PULLUP);
	pinMode(config::HC_SR04_TRIG_PIN, OUTPUT);
	pinMode(config::HC_SR04_ECHO_PIN, INPUT);

	digitalWrite(config::LED_INDICATOR_PIN, LOW);
	digitalWrite(config::HC_SR04_TRIG_PIN, LOW);

	analogReadResolution(12);
	analogSetPinAttenuation(config::POT_PIN, ADC_11db);

	Wire.begin(config::I2C_SDA_PIN, config::I2C_SCL_PIN);
	Wire.setClock(400000);

	dataMutex = xSemaphoreCreateMutex();
	i2cMutex = xSemaphoreCreateMutex();
	buttonSemaphore = xSemaphoreCreateBinary();
	sdMutex = xSemaphoreCreateMutex();
	sensorQueue = xQueueCreate(1, sizeof(SensorData));

	if (dataMutex == nullptr || i2cMutex == nullptr || buttonSemaphore == nullptr || sdMutex == nullptr || sensorQueue == nullptr) {
		Serial.println(F("Fatal: FreeRTOS resource allocation failed."));
		while (true) {
			vTaskDelay(pdMS_TO_TICKS(1000));
		}
	}

	dht.begin();

	displayReady = display.begin(SSD1306_SWITCHCAPVCC, config::OLED_ADDRESS);
	if (displayReady) {
		if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
			display.clearDisplay();
			display.setTextSize(1);
			display.setTextColor(SSD1306_WHITE);
			display.setCursor(0, 0);
			display.println(F("Booting system..."));
			display.display();
			xSemaphoreGive(i2cMutex);
		}
	} else {
		Serial.println(F("Warning: OLED not detected."));
	}

	rtcReady = rtc.begin();
	if (rtcReady) {
		if (rtc.lostPower()) {
			rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
		}
	} else {
		Serial.println(F("Warning: DS3231 not detected."));
	}

	sdReady = initSDCard();
	if (!sdReady) {
		Serial.println(F("Warning: SD card not detected."));
	}

	attachInterrupt(digitalPinToInterrupt(config::BUTTON_PIN), buttonISR, FALLING);

	xTaskCreatePinnedToCore(TaskDHT, "TaskDHT", config::STACK_DHT, nullptr, 1, &taskDHTHandle, 1);
	xTaskCreatePinnedToCore(TaskRTC, "TaskRTC", config::STACK_RTC, nullptr, 1, &taskRTCHandle, 1);
	xTaskCreatePinnedToCore(TaskADC, "TaskADC", config::STACK_ADC, nullptr, 1, &taskADCHandle, 1);
	xTaskCreatePinnedToCore(TaskUltrasonic, "TaskUltrasonic", config::STACK_ULTRASONIC, nullptr, 1, &taskUltrasonicHandle, 1);
	xTaskCreatePinnedToCore(TaskOLED, "TaskOLED", config::STACK_OLED, nullptr, 2, &taskOLEDHandle, 0);
	xTaskCreatePinnedToCore(TaskLED, "TaskLED", config::STACK_LED, nullptr, 2, &taskLEDHandle, 0);
	xTaskCreatePinnedToCore(TaskSDCard, "TaskSDCard", config::STACK_SD, nullptr, 1, &taskSDHandle, 0);
	xTaskCreatePinnedToCore(TaskButton, "TaskButton", config::STACK_BUTTON, nullptr, 3, &taskButtonHandle, 0);

	copySharedDataToQueue();

	Serial.println(F("Smart Environment Monitoring System ready."));
}

void loop() {
	vTaskDelay(pdMS_TO_TICKS(1000));
}
